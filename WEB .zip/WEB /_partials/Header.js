module.exports = class{
    render(){
        return `
        <!-- your header here -->
        `;
    }
}